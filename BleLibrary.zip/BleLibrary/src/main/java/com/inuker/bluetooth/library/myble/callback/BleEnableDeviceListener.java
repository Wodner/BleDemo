package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/24 10:14
 * 邮箱：wuwende@live.cn
 */

public interface BleEnableDeviceListener {

    void onEnable(boolean isSet);

}
