package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/25 21:09
 * 邮箱：wuwende@live.cn
 */

public interface BleCalibrateSitPositionListener {

    void onCalibrate(boolean isSuccess);

}
