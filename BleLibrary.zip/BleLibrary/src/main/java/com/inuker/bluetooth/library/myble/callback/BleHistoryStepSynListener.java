package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/24 23:13
 * 邮箱：wuwende@live.cn
 */

public interface BleHistoryStepSynListener {
    void onFinish(boolean isFinish);
}
