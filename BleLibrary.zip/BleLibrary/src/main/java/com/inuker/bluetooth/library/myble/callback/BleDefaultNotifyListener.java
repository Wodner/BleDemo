package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/24 22:09
 * 邮箱：wuwende@live.cn
 */

public interface BleDefaultNotifyListener {

    void onOpen(boolean isOpen);
}
