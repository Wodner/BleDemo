package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/23 17:38
 * 邮箱：wuwende@live.cn
 */

public interface BleCurrentStatusListener {
    void onCurrentStatus(String result);
}
