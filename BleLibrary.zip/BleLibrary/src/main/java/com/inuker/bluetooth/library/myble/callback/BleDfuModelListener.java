package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/23 14:03
 * 邮箱：wuwende@live.cn
 */

public interface BleDfuModelListener {

    void onDfuModel(boolean isDfu);
}
