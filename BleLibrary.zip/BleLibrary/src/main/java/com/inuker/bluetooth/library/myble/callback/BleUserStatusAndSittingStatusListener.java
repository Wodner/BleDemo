package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/24 21:53
 * 邮箱：wuwende@live.cn
 */

public interface BleUserStatusAndSittingStatusListener {

    void onStatus(String userStatus,String sittingStatus);
}
