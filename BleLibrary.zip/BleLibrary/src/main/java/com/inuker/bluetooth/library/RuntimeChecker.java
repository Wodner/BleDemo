package com.inuker.bluetooth.library;


public interface RuntimeChecker {
    void checkRuntime();
}
