package com.inuker.bluetooth.library.myble.callback;

/**
 * 描述：
 * 作者：Wu on 2017/4/24 20:17
 * 邮箱：wuwende@live.cn
 */

public interface BleCurrentStepListener {

    void onStep(String result);

}
